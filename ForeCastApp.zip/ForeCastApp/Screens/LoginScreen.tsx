import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch } from 'react-redux';
import { setUsername } from '../redux/authSlice';  // Import your action

const LoginScreen = () => {
  const [username, setUsernameState] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation();
  const dispatch = useDispatch(); // Redux dispatch hook

  const handleLoginApi = async () => {
    // Check if username and password meet the validation criteria
    if (username.length >= 4 && password.length >= 4) {
      try {
        // Call the API to validate login
        const response = await fetch('http://localhost:3000/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: username,
            password: password,
          }),
        });
  
        // Parse the response from the server
        const data = await response.json();
  
        if (response.ok) {
          // If login is successful, dispatch the username to Redux
          dispatch(setUsername(username));
          navigation.replace('TabBarScreen');  // Navigate to the next screen
        } else {
          // Handle login failure (e.g., wrong credentials)
          Alert.alert('Login Failed', data.message || 'Invalid credentials');
        }
      } catch (error) {
        console.error('Error during login:', error);
        Alert.alert('Login Failed', 'Something went wrong. Please try again.');
      }
    } else {
      // If input validation fails, show an alert
      Alert.alert('Invalid Input', 'Please enter a valid username and password.');
    }
  };

  const handleLogin = () => {
    // Replace this with actual authentication logic
    if (username.length >= 4 && password.length >= 4) {
        //Call API 
        dispatch(setUsername(username));

     navigation.replace('TabBarScreen');  // Navigate to TabBar on successful login
    //  navigation.navigate('Home', { username });
     // navigation.navigate('Home', { username: 'JohnDoe' });

    } else {
        console.log("It is going to else block");
        Alert.alert(
            'Invalid Input',  // Title of the alert
            'Please enter valid  username and password.',  // Message in the alert
            [{ text: 'OK' }]  // Button
          );
     
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsernameState}
        autoCorrect={false}
        autoCapitalize="none" 
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
        autoCorrect={false}
      />
      <Button title="Login" onPress={handleLoginApi} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
});

export default LoginScreen;
function alert(arg0: string) {
    throw new Error('Function not implemented.');
}

