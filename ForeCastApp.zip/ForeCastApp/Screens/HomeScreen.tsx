import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'; // Importing icons from FontAwesome
import homeImage from '../assets/nisumLogo.webp';
import { useRoute} from '@react-navigation/native'
import { useSelector } from 'react-redux'; // Import useSelector to access Redux store

const HomeScreen = () => {
  const username = useSelector((state) => state.auth.username);
 console.log("The stored username is",username);
  return (
    <View style={styles.container}>
     <Image 
        source={homeImage} 
        style={styles.image}
        resizeMode="contain"  // Optional: how the image should be resized
      />
      <Text style={styles.title}>
        {username ? `Welcome, ${username}!` : 'Welcome!'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginTop:0,
  },
  image: {
    width: 200,    // Width of the image
    height: 200,
    marginLeft:20,
  },
});

export default HomeScreen;
