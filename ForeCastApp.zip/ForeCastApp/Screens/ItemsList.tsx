import React, { useState } from 'react';
import { View, Text, FlatList, Linking, StyleSheet } from 'react-native';
import TableView from '../Components/TableView';
import HyperlinkTable from '../Components/HyperLinkTable';
import placesData from '../JsonFiles/places.json'


const ItemsList = () => {
    const [data] = useState(placesData); // Load local JSON data into state
 
    const simpleData = [
        { id: 1, name: 'John Doe', age: 28, city: 'New York' },
        { id: 2, name: 'Jane Smith', age: 34, city: 'Los Angeles' },
        { id: 3, name: 'Sam Johnson', age: 45, city: 'Chicago' },
        { id: 4, name: 'Emily Davis', age: 22, city: 'Miami' },
      ];

      return (
        <View style={styles.container}>
          <TableView data={simpleData} />
          <HyperlinkTable data={data} />
        </View>
        
      );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    },
    item: {
        backgroundColor: '#f9c2ff',
        padding: 20,
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 10,
      },
      title: {
        fontSize: 18,
        fontWeight: 'bold',
      },
      body: {
        fontSize: 14,
      },
  });

export default ItemsList;
