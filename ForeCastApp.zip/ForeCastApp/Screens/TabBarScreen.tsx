import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from './HomeScreen'
import SettingsScreen from './SettingsScreen'
import WeatherScreen from './WeatherScreen'
import WebViewScreen from './WebViewScreen'

import { Image } from 'react-native';

import homeIcon from '../assets/home.png'
import settingsIcon from '../assets/settings.png'
import weatherIcon from '../assets/cloud.png'
import webIcon from '../assets/web.png'
import listIcon from '../assets/list.png'

import ItemsList from './ItemsList';

const Tab = createBottomTabNavigator();

const getTabIcon = (routeName: String, focused: boolean) => {
    let icon;

    switch (routeName) {
        case 'Home':
            icon = homeIcon;
            break;
        case 'Settings':
            icon = settingsIcon;
            break;
        case 'Weather':
            icon = weatherIcon;
            break;
        case 'WebView':
            icon = webIcon;
            break;
        case 'List':
            icon = listIcon
            break;
        default:
            icon = homeIcon;
    }
    return (
        <Image
          source={icon}
          style={{
          width: 25,
          height: 25,
          tintColor: focused ? 'blue' : 'gray',
        }}
       />
    )
}
const TabBarScreen = () => {
  return (
    <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused }) => getTabIcon(route.name, focused),
      tabBarActiveTintColor: 'blue',    // Active tab icon color
      tabBarInactiveTintColor: 'gray',  // Inactive tab icon color
      tabBarStyle: {
        backgroundColor: '#fff',        // TabBar background color
      },
    })}
  >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
      <Tab.Screen name="Weather" component={WeatherScreen} />
      <Tab.Screen name="WebView" component={WebViewScreen} />
      <Tab.Screen name="List" component={ItemsList} />

    </Tab.Navigator>
  );
};

export default TabBarScreen;
