import React, {useState} from "react";
import {View, Text, StyleSheet, TextInput, Button, ActivityIndicator, Alert} from 'react-native';

interface WeahterInfo {
    temperature: number;
    description: string;
    windSpeed: number;
    city: string;
  }

const WeatherScreen = ( { navigation }) => {
    const [city, setCity] = useState('');
  const [loading, setLoading] = useState(false);
  const [weather, setWeather] = useState<WeahterInfo | null>(null);
  const [error, setError] = useState(null);
  const API_KEY = '98b83fe586ad988905ab93573ddd43b7';
  const [joke, setJoke] = useState('');

    const [username, setUsername] = useState('');

    //function to getjoke from API 
  const getJoke = async() => {
    setLoading(true);
     try {
        const response = await fetch('https://api.chucknorris.io/jokes/random');
        const json = await response.json();
        setJoke(json.value);
     }
     catch(err) {
         console.log(err);
     }
     finally{
      setLoading(false);
     }
  }

    //function to fetch weather data from API 
  const fetchWeather = async (cityName: any) => {
    //console.log("The city name",cityName, API_KEY);
    //getJoke();
   setLoading(true);
    try {
     const response = await fetch
       (`https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${API_KEY}&units=metric`);
    
    // const jokeResponse = await axios.get('https://api.chucknorris.io/jokes/random');
        console.log('Weahter Information is  ');
        const data = await response.json();

        console.log("TTTT",data);
        console.log("TTTT code",data.cod);
        console.log("TTTT message",data.message);
        const weatherInfo: WeahterInfo = {
          temperature: data.main.temp,
          description: data.weather[0].description,
          windSpeed: data.wind.speed,
          city: data.name,
        }
        console.log("TTTT code ",data.cod);
        console.log("TTTT message",data.message);

        if (data.cod === '404') {
            Alert.alert(
              'Invalid Input',  // Title of the alert
              'Please enter a valid city',  // Message in the alert
              [{ text: 'OK' }]  // OK Button
            );
          } else {
            console.log(weatherInfo);
            setWeather(weatherInfo);
        }
        
  
     

    } catch(err) {
      console.log(err);
     // {"cod": "404", "message": "city not found"}
     // LOG  [TypeError: Cannot read property 'temp' of undefined]
      if (err.cod == "404"){
        Alert.alert(
            'Invalid Input',  // Title of the alert
            'Please enter valid city',  // Message in the alert
            [{ text: 'OK' }]  // Button
          );
      }
     
    } finally{
      setLoading(false);
    }
   
  };

    return (
    <View style={styles.container}>
      {loading ? (
      <ActivityIndicator size="large" color="#000ff"/>
      ) :
      (<>
      <Text style={styles.title}> Weather App</Text>
      <TextInput style={styles.input}
       placeholder="Enter City"
       value={city}
       onChangeText={ text => setCity(text)}/>
        <Button title='Get Weather Information'
        onPress={() => fetchWeather(city)} />
        {/* {joke && <Text style={styles.joke}>{joke}</Text>} */}
        {weather && (
          <View style={styles.weatherTable}>
              <View style={styles.tableRow}>
              <Text style={styles.tableCellLabel}>City:</Text>
              <Text style={styles.tableCellValue}>{weather.city}</Text>
            </View>
            <View style={styles.tableRow}>
            <Text style={styles.tableCellLabel}>Temperature:</Text>
            <Text style={styles.tableCellValue}>{weather.temperature}</Text>
            </View>
            <View style={styles.tableRow}>
            <Text style={styles.tableCellLabel}>Description:</Text>
            <Text style={styles.tableCellValue}>{weather.description}</Text>
            </View>
            <View style={styles.tableRow}>
            <Text style={styles.tableCellLabel}>Wind Speed:</Text>
            <Text style={styles.tableCellValue}>{weather.windSpeed}</Text>
            </View>
            {/* <Text>Temp</Text> */}
          </View>
        )}
        </>
        )
      }
    </View>
  );
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      padding: 16,
      backgroundColor: '#f0f8ff',
    },
    joke: {
      marginTop:20,
      fontSize:18,
      textAlign: 'center',
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold',
      marginBottom: 20,
    },
    input: {
      height: 40,
      borderColor: '#ccc',
      borderWidth: 1,
      paddingHorizontal: 10,
      width: '100%',
      marginBottom: 10,
      borderRadius: 5,
    },
    weatherTable: {
     marginTop: 20,
     marginHorizontal:10,
    // paddingHorizontal:16,
    },
    tableRow: {
     flexDirection: 'row',
     justifyContent: 'space-between',
     marginHorizontal:10,
     paddingVertical: 8,
     borderBottomWidth: 1,
     borderBottomColor: '#ccc',
    },
    tableCellLabel: {
      fontWeight: 'bold',
      flex:1,
    },
    tableCellValue: {
      flex:1,
      textAlign: 'right'
    },
  });

  
export default WeatherScreen;
