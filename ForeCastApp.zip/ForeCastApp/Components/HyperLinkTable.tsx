import React from 'react';
import { View, Text, FlatList, StyleSheet, Linking } from 'react-native';
const HyperlinkTable = ({ data }) => {

  const renderItem = ({ item }) => (
    <View style={styles.row}>
      <Text style={styles.cell}>{item.title}</Text>
      <Text style={styles.cell}>{item.description}</Text>
      <Text
        style={styles.linkCell}
        onPress={() => Linking.openURL(item.pageUrl)}
      >
        {item.title}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerCell}>Topic</Text>
        <Text style={styles.headerCell}>Description</Text>
        <Text style={styles.headerCell}>Website</Text>
      </View>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    overflow: 'hidden',
    margin: 10,
  },
  header: {
    flexDirection: 'row',
    backgroundColor: '#f0f0f0',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  headerCell: {
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  row: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  cell: {
    flex: 1,
    textAlign: 'center',
  },
  linkCell: {
    flex: 1,
    textAlign: 'center',
    color: 'blue',
    textDecorationLine: 'underline',
  },
});

export default HyperlinkTable;
