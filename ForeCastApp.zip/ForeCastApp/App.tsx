/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import type {PropsWithChildren} from 'react';

import LoginScreen from './Screens/LoginScreen'
import TabBarScreen from './Screens/TabBarScreen'

import {
  StyleSheet
} from 'react-native';

import { Provider } from 'react-redux';
import store from '../ForeCastApp/redux/store'
///Users/hjana/Documents/
//ReactNativePOC/ReduxSamples/ForeCastApp/redux/store"' instead
import { createStackNavigator } from '@react-navigation/stack';

type SectionProps = PropsWithChildren<{
  title: string;
}>;


const Stack = createStackNavigator();
function App(): React.JSX.Element {
  


  return (
    <Provider store={store}> 
    <NavigationContainer>
      <Stack.Navigator initialRouteName='LoginScreen'>
        <Stack.Screen name='Login' component={LoginScreen}
        options={{ headerShown: false }}
        />
        <Stack.Screen name='TabBarScreen' component={TabBarScreen}
        options={{ headerShown: false }}
        />
      </Stack.Navigator>
   </NavigationContainer>
   </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default App;
