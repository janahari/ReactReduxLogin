//Action types 
const SET_USERNAME = "SET_USERNAME";
const CLEAR_USERNAME = "CLEAR_USERNAME";

// Action Creators
export const setUsername = (username) => ({
    type: SET_USERNAME,
    payload: username,
  });
  
export const clearUsername = () => ({
    type: CLEAR_USERNAME,
  });

//Initial State 
const initialState = {
    username: "",
}

//Reducer
const authReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case SET_USERNAME:
            return {
                ...state,
                username: action.payload
            };
            case CLEAR_USERNAME:
                return {
                    ...state,
                    username: "",
                };
            default:
                return state;
    }
};
export default authReducer;
