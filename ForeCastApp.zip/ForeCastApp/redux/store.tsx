// src/redux/store.js
import { createStore, combineReducers } from 'redux';
import authReducer from './authSlice'; // Your auth reducer

// Combine reducers (in case you have multiple reducers)
const rootReducer = combineReducers({
  auth: authReducer, // This should match your reducer key
});

// Create the Redux store
const store = createStore(rootReducer);

export default store; // Make sure you're exporting the store
